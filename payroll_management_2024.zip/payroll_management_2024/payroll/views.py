from django.shortcuts import render,redirect
from payroll.models import payroll,Contact

# Create your views here.
def home(request):
    return render(request,'home.html')
def payroll_register(request):
     if request.method=='POST':
         First=request.POST.get('First_name')
         Last=request.POST.get('Last_name')
         phone=request.POST.get('phone_number')
         Salary=request.POST.get('Salary')
         department=request.POST.get('department_name')
         pay=payroll(First_name=First, Last_name= Last,phone_number=phone,Salary=Salary,department_name=department)
         pay.save() 
     return render(request, 'payroll_register.html')

def payroll_list(request):
    payrolls = payroll.objects.all()
    context={'payrolls': payrolls}
    return render(request, 'payroll_list.html',context)



def contact(request):
     
 if request.method=='POST':
         first=request.POST.get('first_name')
         last=request.POST.get('last_name')
         contact=request.POST.get('contact_number')
         email=request.POST.get('email')
        
         pay=Contact(first_name=first, last_name= last,contact_number=contact,email=email)
         pay.save()
                
 return render(request, 'contact.html')


def contacts(request):
 contacts = Contact.objects.all()
 context={'contacts': contacts}
 return render(request, 'payroll_list.html',context)
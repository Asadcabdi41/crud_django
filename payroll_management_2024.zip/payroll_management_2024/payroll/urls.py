from django.urls import path
from.import views

urlpatterns = [
       path('home/', views.home),
        path('register/', views.payroll_register),
         path('List/', views.payroll_list ),
         path('contact/', views.contact, name='contact'),

   ]